const cards = document.querySelectorAll('.info-card, .project-card, .resume-section, .timeline-item, .hero-card');

cards.forEach((card, index) => {
  card.style.opacity = '0';
  card.style.transform = 'translateY(12px)';
  setTimeout(() => {
    card.style.transition = 'opacity 500ms ease, transform 500ms ease';
    card.style.opacity = '1';
    card.style.transform = 'translateY(0)';
  }, 100 + index * 80);
});
